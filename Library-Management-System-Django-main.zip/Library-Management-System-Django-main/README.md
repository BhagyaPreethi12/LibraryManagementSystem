# Library-Management-System-Django

import this in system --> celery 



**In Settings.py**
  - from celery import Celery
  - from celery.schedules import crontab

**NOTICE:**
  - The roles should be approved by the admin in the admin site.....


**TWO ROLES:**
  - 1.LIBRARIAN
  - 2.STUDENT


**1.Librarian:**
  - Librarian can access all the features in system.
  - Where he can add books,delete books,issuebook to the students,view all students in the management etc...

**2.Student:**
  - Student can view their profile,change their account password,request books,and etc..


**admin credintials**
  - username : admin
  - password : rahul@1234


**librarian credintials**
  - username: librarian
  - password: rahul@1234


**student credintials**
  - username : rahul
  - password : rahul@1234

**Here some of the attachments to provide basic knowledge on this project...**

![Screenshot (114)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/1bfcaa78-41d9-41e9-862d-085c2d9e8549)

![Screenshot (115)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/3caff9ea-0ca7-43a3-94f1-3a34115f620d)

![Screenshot (116)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/40ac1a7f-b82d-45a7-a7e9-33bd5c58ddc6)

![Screenshot (117)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/a25c89a0-e054-4793-b238-723e7d8b04f4)

![Screenshot (118)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/ded80fa9-7d2e-4c06-90bc-5ad5f6481de8)

![Screenshot (119)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/a708d51d-2c5e-4ed4-84fc-4c89a68456f5)

![Screenshot (120)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/dc70d893-8364-492d-976d-8f24bcf83bc7)

![Screenshot (121)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/351307da-e2ab-4fee-a434-5c227b886a5d)

![Screenshot (122)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/27f73147-4d2f-4d75-9b26-118a0906c34f)

![Screenshot (123)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/55c3b9df-be61-4940-bff0-90a614a5998d)

![Screenshot (124)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/dd5dd935-6f20-4d54-a21b-a7a7ad818e3b)

![Screenshot (125)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/d9a2b03e-91b1-4e06-aa8c-958ffe840aa8)

![Screenshot (126)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/383c3d88-842c-406b-a52e-7c4d79eefdad)

![Screenshot (127)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/a81764a5-3a8e-47d9-8823-17dc0bbc08fa)

![Screenshot (128)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/6a0f6eea-88ce-4049-b4fa-5b3dca22ac5a)

![Screenshot (129)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/fccf1358-b424-4930-a94d-dad503525d8d)

![Screenshot (130)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/bd8c414f-c380-4435-a2db-d0d6682444f0)

![Screenshot (131)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/3c3bfd0b-b660-45d4-9294-e1d48bb82bf3)

![Screenshot (132)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/42f7e110-591f-4d28-b985-0db1240ae450)

![Screenshot (133)](https://github.com/Rahulreddy67/Library-Management-System-Django/assets/132583519/a0a2732a-cf51-4bf7-a6b6-7813fe6dc033)











